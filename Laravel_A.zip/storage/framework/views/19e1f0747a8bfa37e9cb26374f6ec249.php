<?php $__env->startSection('content'); ?>
    <div class="main-content mt-5">
        <div class="row">
            <div class="col-12">
                <div class="card mb-5">
                    <div class="card-header">
                        <span style="font-weight:600;font-size: 20px;">Trashed Posts</span>
                        <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-info"
                            style="float: right; margin-right:10px;">All Posts</a>
                        <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary"
                            style="float: right; margin-right:10px;">Create</a>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered border-dark">
                            <thead>
                                <tr>
                                    <th scope="col" style="width:5%; text-align:center;">#</th>
                                    <th scope="col" style="width:10%; text-align:center;">Image</th>
                                    <th scope="col" style="width:10%; text-align:center;">Title</th>
                                    <th scope="col" style="width:30%; text-align:center; justify-content:center;">
                                        Description</th>
                                    <th scope="col" style="width:10%; text-align:center;">Category</th>
                                    <th scope="col" style="width:15%; text-align:center;">Publish Date</th>
                                    <th scope="col" style="width:20%; text-align:center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row" style="text-align: center;"><?php echo e($post->id); ?></th>

                                        <td style="text-align: center;"><img src="<?php echo e(asset($post->image)); ?>" alt=""
                                                width="80" height="70"></td>

                                        <td style="text-align: center;"><?php echo e($post->title); ?></td>

                                        <td style="text-align: center;"><?php echo e($post->description); ?>

                                        </td>

                                        <td style="text-align: center;"><?php echo e($post->category->name); ?></td>

                                        <td style="text-align: center;"><?php echo e(date('d-m-Y', strtotime($post->created_at))); ?>

                                        </td>

                                        <td style="text-align: center;">
                                            <div class="d-flex">

                                                <a href="<?php echo e(route('posts.restore', $post->id)); ?>"
                                                    class="btn btn-sm btn-success me-2">Restore</a>

                                                <form action="<?php echo e(route('posts.force_delete', $post->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger"
                                                        onclick="return confirm('Are you sure you want to delete this item permanently?')">Delete</button>
                                                </form>

                                            </div>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>

                        <?php echo e($posts->links()); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal -->
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_A\resources\views/posts/trashed.blade.php ENDPATH**/ ?>