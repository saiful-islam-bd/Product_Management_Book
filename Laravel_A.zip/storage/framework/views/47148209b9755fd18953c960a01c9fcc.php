<?php $__env->startSection('content'); ?>
    <div class="main-content mt-5">
        <div class="row">
            <div class="col-2"></div>

            <div class="col-8">
                <div class="card mb-5">
                    <div class="card-header">
                        <span style="font-weight:600;font-size: 20px;">Authenticated Users Data</span>

                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered border-dark">
                            <thead>
                                <tr>
                                    <th scope="col" style="width:5%; text-align:center;">#</th>
                                    <th scope="col" style="width:10%; text-align:center;">Name</th>
                                    <th scope="col" style="width:10%; text-align:center;">Email</th>
                                    <th scope="col" style="width:15%; text-align:center;">Created at</th>
                                    <th scope="col" style="width:10%; text-align:center;">Status</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row" style="text-align: center;"><?php echo e($user->id); ?></th>

                                        <td style="text-align: center;"><?php echo e($user->name); ?></td>

                                        <td style="text-align: center;"><?php echo e($user->email); ?>

                                        </td>

                                        <td style="text-align: center;"><?php echo e(date('d-m-Y', strtotime($user->created_at))); ?>

                                        </td>

                                        <td style="text-align: center;"><?php echo e($user->role->name); ?>

                                        </td>


                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tbody>
                        </table>

                        

                    </div>
                </div>
            </div>

            <div class="col-2"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_A\resources\views/users/users.blade.php ENDPATH**/ ?>