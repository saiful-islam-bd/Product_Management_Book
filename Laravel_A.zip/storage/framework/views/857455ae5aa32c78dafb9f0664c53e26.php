
<div class="row">
    <div class="col-2"></div>

    <div class="col-8">
        <div class="card p-5">
            <h4 class="text-lg font-medium text-gray-600">Profile Information</h4>
            <p class="mt-1 text-sm text-gray-400">
                Update your account's profile information and email address.
            </p>

            <form id="send-verification" method="post" action="<?php echo e(route('verification.send')); ?>">
                <?php echo csrf_field(); ?>
            </form>
        
            <form method="post" action="<?php echo e(route('profile.update')); ?>" class="mt-6 space-y-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>

                <div class="mb-3">
                    <label for="" class="form-label">Name</label>
                    <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control" id=""
                        placeholder="Title">
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Email</label>
                    <input type="text" name="email" value="<?php echo e($user->email); ?>" class="form-control" id=""
                        placeholder="Email">
                </div>
        
              
                    <?php if($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && ! $user->hasVerifiedEmail()): ?>
                        <div>
                            <p class="text-sm mt-2 text-gray-800">
                                <?php echo e(__('Your email address is unverified.')); ?>

        
                                <button form="send-verification" class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                    <?php echo e(__('Click here to re-send the verification email.')); ?>

                                </button>
                            </p>
        
                            <?php if(session('status') === 'verification-link-sent'): ?>
                                <p class="mt-2 font-medium text-sm text-green-600">
                                    <?php echo e(__('A new verification link has been sent to your email address.')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
        
                <div class="flex items-center gap-4">
                    <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e(__('Save')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
        
                    <?php if(session('status') === 'profile-updated'): ?>
                        <p
                            x-data="{ show: true }"
                            x-show="show"
                            x-transition
                            x-init="setTimeout(() => show = false, 2000)"
                            class="text-sm text-gray-600"
                        ><?php echo e(__('Saved.')); ?></p>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <div class="col-2"></div>
</div>

<?php /**PATH C:\xampp\htdocs\Laravel_A\resources\views/profile/partials/update_profile_info.blade.php ENDPATH**/ ?>