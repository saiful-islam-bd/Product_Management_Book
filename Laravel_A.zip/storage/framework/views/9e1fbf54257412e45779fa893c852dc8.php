<?php $__env->startSection('content'); ?>
    <div class="main-content mt-5">
        <div class="row">
            <div class="col-12">
                <div class="card mb-5">
                    <div class="card-header">
                        <span style="font-weight:600;font-size: 20px;">All Posts</span>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('trash', \App\Models\Post::class)): ?>
                        <a href="<?php echo e(route('posts.trashed')); ?>" class="btn btn-warning"
                        style="float: right; margin-right:10px;">Trashed</a>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', \App\Models\Post::class)): ?>
                            <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary"
                                style="float: right; margin-right:10px;">Create</a>
                        <?php endif; ?>

                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered border-dark">
                            <thead>
                                <tr>
                                    <th scope="col" style="width:5%; text-align:center;">#</th>
                                    <th scope="col" style="width:10%; text-align:center;">Image</th>
                                    <th scope="col" style="width:10%; text-align:center;">Title</th>
                                    <th scope="col" style="width:30%; text-align:center; justify-content:center;">
                                        Description</th>
                                    <th scope="col" style="width:10%; text-align:center;">Category</th>
                                    <th scope="col" style="width:15%; text-align:center;">Publish Date</th>
                                    <th scope="col" style="width:20%; text-align:center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row" style="text-align: center;"><?php echo e($post->id); ?></th>

                                        <td style="text-align: center;"><img src="<?php echo e(asset($post->image)); ?>" alt=""
                                                width="80" height="70"></td>

                                        <td style="text-align: center;"><?php echo e($post->title); ?></td>

                                        <td style="text-align: center;"><?php echo e($post->description); ?>

                                        </td>

                                        <td style="text-align: center;"><?php echo e($post->category->name); ?></td>

                                        <td style="text-align: center;"><?php echo e(date('d-m-Y', strtotime($post->created_at))); ?>

                                        </td>

                                        <td style="text-align: center;">

                                            <div class="d-flex">
                                                <div>
                                                    <a href="<?php echo e(route('posts.show', $post->id)); ?>"
                                                        class="btn btn-sm btn-primary me-1 text-white">Show</a>

                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $post)): ?>
                                                        <a href="<?php echo e(route('posts.edit', $post->id)); ?>"
                                                            class="btn btn-sm btn-success me-2">Edit</a>
                                                    <?php endif; ?>

                                                </div>

                                                <div>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $post)): ?>
                                                    <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="btn btn-sm btn-danger" style="">Delete</button>
                                                    </form>
                                                    <?php endif; ?>

                                                </div>
                                            </div>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>

                        <?php echo e($posts->links()); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_A\resources\views/posts/index.blade.php ENDPATH**/ ?>