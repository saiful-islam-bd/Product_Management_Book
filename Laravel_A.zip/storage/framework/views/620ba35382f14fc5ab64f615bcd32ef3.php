<?php $__env->startSection('content'); ?>
    <div class="main-content mt-5">
        <div class="row">
            <div class="col-1"></div>

            <div class="col-10">
                <div class="card mb-5">
                    <div class="card-header">
                        <span style="font-weight:600;font-size: 20px;">Show Post</span>
                        <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-primary"
                            style="float: right; margin-right:10px;">Back</a>
                    </div>

                    <div class="card-body ps-5 pe-5">
                        <div class="text-center">
                            <img src="<?php echo e(asset($post->image)); ?>" alt="Image" style="width: 400px; height:400px;">
                        </div>
                        <div class="p-4">
                            <p style="margin-bottom: 0rem;"><span style="font-weight: 600;">Title:</span>
                                <?php echo e($post->title); ?></p>
                            <p style="margin-bottom: 0rem;"><span style="font-weight: 600;">Category:</span>
                                <?php echo e($post->category->name); ?></p>
                            <p style="margin-bottom: 0rem;"><span style="font-weight: 600;">Published at:</span>
                                <?php echo e(date('d-m-Y', strtotime($post->created_at))); ?></p>
                            <p style="margin-bottom: 0rem;"><span style="font-weight: 600;">Description:</span>
                                <?php echo e($post->description); ?></p>
                        </div>

                    </div>
                </div>
            </div>

            <div class="col-1"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_A\resources\views/posts/show.blade.php ENDPATH**/ ?>